package com.ssafy.cloneNova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloneNovaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloneNovaApplication.class, args);
	}

}

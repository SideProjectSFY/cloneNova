package com.ssafy.cloneNova;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloneNovaApplicationTests {

	@Test
	void contextLoads() {
	}

}
